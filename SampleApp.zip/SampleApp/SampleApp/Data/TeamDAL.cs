﻿using SampleApp.Entity;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace SampleApp.Data
{
    public class TeamDAL
    {
        #region Static Members 
        private static List<Team> Teams = new List<Team>();
        #endregion

        static TeamDAL()
        {
            int lines = 0;
            using (var reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(@"~\App_Data\CollegeFootballTeamWinsWithMascots.csv")))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    lines++;
                    if (lines == 1)
                    {
                        continue;
                    }

                   
                    var values = line.Split(',');
                    Team team = new Team();
                    Type type = team.GetType();

                    PropertyInfo[] properties = type.GetProperties();
                    for(var record=0; record< properties.Length; record++)
                    {
                        PropertyInfo property = properties[record];
                        dynamic propertyValue = values[record];
                        switch (property.PropertyType.ToString())
                        {
                            case "System.Nullable`1[System.Int32]":
                                int integerPropertyValue = 0;
                                if (int.TryParse(propertyValue, out integerPropertyValue))
                                {
                                    propertyValue = integerPropertyValue;
                                }
                                else
                                {
                                    propertyValue = null;
                                }
                                break;
                            case "System.Nullable`1[System.Double]":

                                double doublePropertyValue = 0;
                                if (double.TryParse(propertyValue, out doublePropertyValue))
                                {
                                    propertyValue = doublePropertyValue;
                                }
                                else
                                {
                                    propertyValue = null;
                                }
                                break;
                            case "System.Nullable`1[System.DateTime]":
                                DateTime dateTimePropertyValue;
                                string[] formats = {
                                                    "M/d/yyyy", 
                                                    "M/dd/yyyy", 
                                                    "M/d/yy", 
                                                    "M/dd/yy", 
                                                     "MM/d/yyyy", 
                                                    "MM/dd/yyyy",
                                                    "MM/d/yy", 
                                                    "MM/dd/yy"
                                                  };

                                if (DateTime.TryParseExact(propertyValue, formats, CultureInfo.InvariantCulture,
                                               DateTimeStyles.None, out dateTimePropertyValue))
                                {
                                    propertyValue = dateTimePropertyValue;
                                }
                                else
                                {
                                    propertyValue = null;
                                }
                                break;
                        }

                        property.SetValue(team, propertyValue, null);
                    }

                    Teams.Add(team);
                }
            }
        }

        public List<Team> GetTeamsData()
        {
            return Teams;
        }
    }
}