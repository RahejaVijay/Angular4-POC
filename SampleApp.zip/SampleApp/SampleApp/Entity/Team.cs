﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleApp.Entity
{
    public class Team
    {
        public int? Rank { get; set; }
        public string TeamName { get; set; }
        public string Mascot { get; set; }
        public DateTime? DateOfLastWin { get; set; }
        public double? WinningPercetnage { get; set; }
        public int? Wins { get; set; }
        public int? Losses { get; set; }
        public int? Ties { get; set; }
        public int? Games { get; set; }
    }
}