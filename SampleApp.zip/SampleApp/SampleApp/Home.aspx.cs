﻿using SampleApp.Data;
using SampleApp.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SampleApp
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                grdTeams.PageIndex = 1;
                BindTeams();
              
            }
        }

       protected void grdTeams_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTeams.PageIndex = e.NewPageIndex;
            this.BindTeams();
        }


        private void BindTeams()
        {
            TeamDAL teamDAL = new TeamDAL();
            List<Team> teams = teamDAL.GetTeamsData();


            // integer will be compared
            string searchText = txtSearch.Text.Trim();
            int searchedValue = 0;
            double winningPercetnage = 0;
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                switch (ddlColumns.SelectedValue)
                {       
                    case "All":
                        var result = from t in teams
                                     where
                                      Convert.ToString(t.Rank) == searchText
                                     || t.TeamName == searchText
                                     || t.Mascot == searchText
                                     || (t.DateOfLastWin ==null ? "" : t.DateOfLastWin.Value.ToString("MM/dd/yy")) == searchText
                                     || Convert.ToString(t.WinningPercetnage) == searchText
                                     || Convert.ToString(t.Wins) == searchText
                                     || Convert.ToString(t.Losses) == searchText
                                     || Convert.ToString(t.Ties) == searchText
                                     || Convert.ToString(t.Games) == searchText
                                     select t;
                        teams = result.ToList();
                                     
                        break;
                    case "Rank":
                         searchedValue = 0;
                        if (int.TryParse(searchText, out searchedValue))
                        {
                            teams = teams.Where(t => t.Rank == searchedValue).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                    case "TeamName":
                        teams = teams.Where(t => t.TeamName.Trim() == searchText.Trim()).ToList();                       
                        break;
                    case "Mascot":
                        teams = teams.Where(t => t.Mascot == searchText).ToList(); 
                        break;
                    case "DateOfLastWin":
                        teams = teams.Where(t => t.DateOfLastWin!=null && t.DateOfLastWin.Value.ToString("MM/dd/yy") == searchText).ToList();;
                        break;
                    case "WinningPercetnage":
                        winningPercetnage = 0;
                        if (double.TryParse(searchText, out winningPercetnage))
                        {
                            teams = teams.Where(t => t.WinningPercetnage == winningPercetnage).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                    case "Wins":
                          searchedValue = 0;
                        if (int.TryParse(searchText, out searchedValue))
                        {
                            teams = teams.Where(t => t.Wins == searchedValue).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                    case "Losses":
                          searchedValue = 0;
                        if (int.TryParse(searchText, out searchedValue))
                        {
                            teams = teams.Where(t => t.Losses == searchedValue).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                    case "Ties":
                          searchedValue = 0;
                        if (int.TryParse(searchText, out searchedValue))
                        {
                            teams = teams.Where(t => t.Ties == searchedValue).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                    case "Games":
                          searchedValue = 0;
                        if (int.TryParse(searchText, out searchedValue))
                        {
                            teams = teams.Where(t => t.Games == searchedValue).ToList();
                        }
                        else
                        {
                            teams = new List<Team>();
                        }
                        break;
                }

            }

            grdTeams.DataSource = teams;
            grdTeams.DataBind();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            BindTeams();

        }

    }
}